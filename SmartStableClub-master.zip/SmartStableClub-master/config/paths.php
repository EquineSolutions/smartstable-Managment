<?php
return [
    'user-images' => '/uploads/images/user/'
];
