export default {
    data: [
        {
            id: 1,
            name: 'Name 1',
            fei_id: '163528',
            gender: 'Male',
            father: 'Father Name',
            mother: 'Mother Name',
        },
        {
            id: 2,
            name: 'Name 2',
            fei_id: '138429',
            gender: 'Male',
            father: null,
            mother: 'Mother Name',
        },
        {
            id: 3,
            name: 'Name 3',
            fei_id: '162175',
            gender: 'Female',
            father: 'Father Name',
            mother: null,
        },
        {
            id: 4,
            name: 'Name 4',
            fei_id: '136963',
            gender: 'Female',
            father: 'Father Name',
            mother: 'Mother Name',
        },
        {
            id: 5,
            name: 'Name 5',
            fei_id: '145328',
            gender: 'Male',
            father: null,
            mother: null,
        }
    ]
}
